## Paul E. Johnson <pauljohn@ku.edu>
## 2015-10-20

This folder contains an example dissertation prepared 
with the LaTeX style file kuthesis.cls.  The example
document is named "thesis-ku."  I suggest you start
by reviewing the PDF output "thesis-ku.pdf".  That
has an abstract that should explain everything. 

The output from this template has been approved by
the Office of the Graduate Dean at KU.  It is not the
only format they might approve, but we know for sure
they will accept this format.

The newest version of the files in this package should always
be available on my personal website in the directory

http://pj.freefaculty.org/guides/Computing-HOWTO/KU-thesis

The zip file KU-thesis-20151102.zip includes everything
in the directory listing on that page. 

