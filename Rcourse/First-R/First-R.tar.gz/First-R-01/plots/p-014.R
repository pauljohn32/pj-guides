###################################################
### code chunk number 14: first-R-01.Rnw:321-326
###################################################
pdf("RegPlot1.pdf", height=6, width=6, paper="special")
plot(y ~ x, main="Here comes a line of best fit!")
mod1 <- lm(y ~ x)
abline(mod1)
dev.off() #turns off pdf output device


