###################################################
### code chunk number 13: p5
###################################################
plot(y ~ x, main="Here comes a line of best fit!")
mod1 <- lm(y ~ x)
abline(mod1)


