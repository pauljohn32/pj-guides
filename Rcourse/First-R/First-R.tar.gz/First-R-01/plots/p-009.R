###################################################
### code chunk number 9: first-R-01.Rnw:246-249
###################################################
set.seed(66565) #initializes random numbers
x <- rnorm(40, m = 7, sd = 10)
y <- rpois(40, lambda = 11)


